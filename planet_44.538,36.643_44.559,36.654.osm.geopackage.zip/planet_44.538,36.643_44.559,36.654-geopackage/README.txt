Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
geopackage by https://gdal.org

Please read the OSM wiki on how to use GeoPackage files:

  https://wiki.openstreetmap.org/wiki/GeoPackage


This GeoPackage file was created on: Thu 22 Oct 10:20:19 UTC 2026
GPS rectangle coordinates (lng,lat): 44.538,36.643 x 44.559,36.654
Script URL: https://extract.bbbike.org/?sw_lng=44.538&sw_lat=36.643&ne_lng=44.559&ne_lat=36.654&format=geopackage.zip&city=Shorsh%2C+Khabat+Quarter%2C+Soran+district%2C+Soran+Central+Subdistrict%2C+Soran+District%2C+Erbil+Governorate%2C+Iraqi+Kurdistan+Region%2C+44008%2C+Iraq&lang=en
Name of area: Shorsh, Khabat Quarter, Soran district, Soran Cent


We welcome your feedback and suggestions. If you find the service useful,
please consider a donation via PayPal or bank transfer:

  https://extract.bbbike.org/community.html

Any amount helps, whether 10, 20 or 50 euros: whatever the service is
worth to you, or whatever you can afford. We need to raise 20 euros a day,
or 600 euros a month, to cover the server costs. Many thanks!

Thanks, Wolfram Schneider

--
Donate to BBBike: https://extract.bbbike.org/community.html
Upgrade to BBBike Pro: https://extract.bbbike.org/support.html
